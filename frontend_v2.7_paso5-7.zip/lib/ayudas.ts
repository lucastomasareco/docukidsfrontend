// Textos de la guía de cada pantalla. Todo el contenido está acá para poder
// cambiarlo sin tocar el diseño (components/PanelAyuda.tsx).

export type PantallaAyuda = 'docs' | 'calendario' | 'hijos' | 'ajustes';

export type ConsejoAyuda = {
  icono: 'cloud-upload-outline' | 'search-outline' | 'reorder-three-outline' | 'folder-open-outline' | 'hand-left-outline' | 'color-palette-outline' | 'calendar-outline'
    | 'add-circle-outline' | 'people-outline' | 'logo-google' | 'lock-closed-outline' | 'mail-outline'
    | 'checkmark-circle-outline' | 'trash-outline' | 'location-outline'
    | 'person-add-outline' | 'key-outline' | 'exit-outline';
  texto: string;
};

export type AyudaDeUnaPantalla = {
  titulo: string;
  // Nombre de la pantalla, para aclarar que la guía es solo de ella.
  nombre: string;
  consejos: ConsejoAyuda[];
};

export const AYUDAS: Record<PantallaAyuda, AyudaDeUnaPantalla> = {
  docs: {
    titulo: 'Ayuda: Documentos',
    nombre: 'Documentos',
    consejos: [
      { icono: 'people-outline', texto: 'Arriba dice "Estás viendo a:" y el nombre de tu hijo. Tocalo para cambiar de hijo: se muestran los documentos del que elijas.' },
      { icono: 'cloud-upload-outline', texto: 'Tocá SUBIR DOCUMENTO y elegí una foto o un PDF (DNI, carnet de vacunas…).' },
      { icono: 'hand-left-outline', texto: 'Para ver un documento, tocalo: se abre en tu Google Drive. Tocá los 3 puntos ⋮ para ver detalles del documento, editarlo, moverlo o eliminarlo.' },
      { icono: 'checkmark-circle-outline', texto: 'Si tiene fecha de vencimiento, la app la detecta y te pide confirmarla. Te avisamos por email antes de que venza.' },
      { icono: 'reorder-three-outline', texto: 'Para ordenar, agarrá el ícono ≡ de un documento y arrastralo: soltalo en otra carpeta, entre otros documentos o arriba, en "A la vista".' },
      { icono: 'folder-open-outline', texto: 'Los documentos se ordenan en carpetas (Documentos, Salud, Escuela). Tocá el título de una carpeta para cerrarla o abrirla; mantenelo presionado para cambiarle el nombre. Con Nueva carpeta creás las que quieras. Las carpetas también aparecen en tu Drive.' },
      { icono: 'color-palette-outline', texto: 'Verde: vigente. Naranja: vence en 30 días o menos. Rojo: vencido.' },
    ],
  },
  calendario: {
    titulo: 'Ayuda: Calendario',
    nombre: 'Calendario',
    consejos: [
      { icono: 'people-outline', texto: 'Arriba dice "Estás viendo a:" y el nombre de tu hijo. Tocalo para cambiar de hijo: se muestran los turnos del que elijas.' },
      { icono: 'add-circle-outline', texto: 'Tocá un día sin turnos para agendar uno nuevo. Para agendar otro turno en un día que ya tiene, mantené presionado ese día o usá el botón +. Si no elegís hora, es de todo el día.' },
      { icono: 'calendar-outline', texto: 'Tocá un día con turnos para ver solo los de ese día. Tocalo de nuevo para ver todos.' },
      { icono: 'hand-left-outline', texto: 'Mantené presionado un turno para editarlo o borrarlo.' },
      { icono: 'mail-outline', texto: 'Los turnos también se guardan en tu Google Calendar.' },
      { icono: 'location-outline', texto: 'Al crear o editar un turno podés agregar el lugar: escribí la dirección y tocá Buscar, o tocá el mapa para marcarlo. En la lista, tocá Ver mapa para ver dónde es y Cómo llegar para abrir Google Maps. Si estás en una familia, los dos ven el mismo lugar.' },
      { icono: 'trash-outline', texto: 'Arriba ves los turnos de hoy y los próximos. Los anteriores quedan guardados: tocá Ver turnos pasados para consultarlos o Borrar turnos viejos para limpiarlos.' },
    ],
  },
  hijos: {
    titulo: 'Ayuda: Hijos',
    nombre: 'Hijos',
    consejos: [
      { icono: 'people-outline', texto: 'Tocá Registrar hijo para crear su perfil. Podés agregar a todos los que quieras.' },
      { icono: 'search-outline', texto: 'Con la lupa buscás a tu hijo por las primeras letras de su nombre (por ejemplo "Luc"). Tocá la X para ver a todos de nuevo.' },
      { icono: 'hand-left-outline', texto: 'Mantené presionado un hijo para cambiarle el nombre o borrarlo.' },
      { icono: 'checkmark-circle-outline', texto: 'El hijo que tocás queda elegido: sus documentos y turnos aparecen en Docs y Calendario.' },
      { icono: 'people-outline', texto: 'Si estás en una familia, los hijos son compartidos: las dos personas ven y editan los mismos. Los cambios del otro los ves al volver a entrar a esta pantalla.' },
    ],
  },
  ajustes: {
    titulo: 'Ayuda: Ajustes',
    nombre: 'Ajustes',
    consejos: [
      { icono: 'logo-google', texto: 'Conectá tu cuenta de Google: es necesaria para subir documentos, agendar turnos y recibir avisos por email. Si estás en una familia, se usa la cuenta de Google del titular y solo él puede conectarla.' },
      { icono: 'people-outline', texto: 'Familia: podés compartir los hijos, documentos y turnos con otra persona (por ejemplo, el otro padre o madre). Son 2 personas como máximo y las dos pueden editar todo. Quien crea la familia es el titular.' },
      { icono: 'person-add-outline', texto: 'Si sos el titular, tocá Generar código de invitación y mandáselo a la otra persona con Copiar invitación. El código dura 24 horas y sirve una sola vez; si generás otro, el anterior deja de servir.' },
      { icono: 'key-outline', texto: 'Si te pasaron un código, tocá Unirme con código y escribilo. Para unirte, tu cuenta tiene que estar sin hijos cargados.' },
      { icono: 'exit-outline', texto: 'El miembro puede Salir de la familia. El titular puede Quitar a la otra persona o Disolver la familia. Quien sale o es quitado queda con la cuenta vacía: no se copia nada.' },
      { icono: 'color-palette-outline', texto: 'Elegí los colores de la app en Apariencia.' },
      { icono: 'lock-closed-outline', texto: 'Desde acá podés cambiar tu contraseña o cerrar sesión.' },
    ],
  },
};

// Rutas de las pestañas -> pantalla de la guía.
export const PANTALLA_POR_RUTA: Record<string, PantallaAyuda> = {
  '/': 'docs',
  '/index': 'docs',
  '/calendario': 'calendario',
  '/hijos': 'hijos',
  '/ajustes': 'ajustes',
};
