import { useRef, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, ScrollView } from 'react-native';
import { Link, useRouter } from 'expo-router';
import { useAuth } from '../../context/AuthContext';
import { useAvisos } from '../../context/AvisosContext';
import CampoContrasena from '../../components/CampoContrasena';

export default function Register() {
  const { registrarse } = useAuth();
  const { mostrarError, mostrarAviso } = useAvisos();
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [cargando, setCargando] = useState(false);
  const claveRef = useRef<TextInput>(null);

  const handleRegister = async () => {
    if (!email || !password) {
      mostrarAviso('Faltan datos', 'Completá email y contraseña.', { icono: 'create-outline' });
      return;
    }
    if (password.length < 6) {
      mostrarAviso('Contraseña muy corta', 'Tiene que tener al menos 6 caracteres.', { icono: 'create-outline' });
      return;
    }
    setCargando(true);
    const { error } = await registrarse(email, password);
    setCargando(false);
    if (error) {
      mostrarError(error, { onReintentar: handleRegister });
      return;
    }
    mostrarAviso('Cuenta creada', 'Revisá tu correo: puede que tengas que confirmar tu email antes de ingresar.', {
      icono: 'checkmark-circle-outline',
      duracion: 9000,
    });
    router.replace('/(auth)/login');
  };

  return (
    <KeyboardAvoidingView behavior="padding" style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
      <Text style={styles.titulo}>Crear cuenta</Text>

      <TextInput placeholderTextColor="#5F5F5F" style={styles.input} placeholder="Email" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" returnKeyType="next" blurOnSubmit={false} onSubmitEditing={() => claveRef.current?.focus()} />
      <CampoContrasena ref={claveRef} placeholderTextColor="#5F5F5F" style={styles.input} placeholder="Contraseña (mín. 6 caracteres)" value={password} onChangeText={setPassword} returnKeyType="go" onSubmitEditing={() => { if (!cargando) handleRegister(); }} />

      <TouchableOpacity style={styles.boton} onPress={handleRegister} disabled={cargando}>
        <Text style={styles.botonTexto}>{cargando ? 'Creando...' : 'Registrarme'}</Text>
      </TouchableOpacity>

      <Link href="/(auth)/login" style={styles.link}>
        <Text style={{ fontSize: 16, color: '#1F1F1F' }}>¿Ya tenés cuenta? Iniciá sesión</Text>
      </Link>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, justifyContent: 'center', padding: 24 },
  titulo: { fontSize: 30, fontWeight: 'bold', textAlign: 'center', marginBottom: 32 },
  input: { borderWidth: 1, borderColor: '#ccc', borderRadius: 8, padding: 12, marginBottom: 12, fontSize: 16, color: '#1F1F1F' },
  boton: { backgroundColor: '#1976d2', padding: 14, borderRadius: 8, alignItems: 'center', marginTop: 8 },
  botonTexto: { color: '#fff', fontWeight: 'bold', fontSize: 18 },
  link: { marginTop: 20, textAlign: 'center' },
});