// Textos de la guía de cada pantalla. Todo el contenido está acá para poder
// cambiarlo sin tocar el diseño (components/PanelAyuda.tsx).

export type PantallaAyuda = 'docs' | 'calendario' | 'hijos' | 'ajustes';

export type ConsejoAyuda = {
  icono: 'cloud-upload-outline' | 'search-outline' | 'reorder-three-outline' | 'folder-open-outline' | 'hand-left-outline' | 'color-palette-outline' | 'calendar-outline'
    | 'add-circle-outline' | 'people-outline' | 'logo-google' | 'lock-closed-outline' | 'mail-outline'
    | 'checkmark-circle-outline' | 'trash-outline';
  texto: string;
};

export type AyudaDeUnaPantalla = {
  titulo: string;
  // Nombre de la pantalla, para aclarar que la guía es solo de ella.
  nombre: string;
  consejos: ConsejoAyuda[];
};

export const AYUDAS: Record<PantallaAyuda, AyudaDeUnaPantalla> = {
  docs: {
    titulo: 'Ayuda: Documentos',
    nombre: 'Documentos',
    consejos: [
      { icono: 'people-outline', texto: 'Arriba dice "Estás viendo a:" y el nombre de tu hijo. Tocalo para cambiar de hijo: se muestran los documentos del que elijas.' },
      { icono: 'cloud-upload-outline', texto: 'Tocá SUBIR DOCUMENTO y elegí una foto o un PDF (DNI, carnet de vacunas…).' },
      { icono: 'checkmark-circle-outline', texto: 'Si tiene fecha de vencimiento, la app la detecta y te pide confirmarla. Te avisamos por email antes de que venza.' },
      { icono: 'hand-left-outline', texto: 'Tocá un documento para abrirlo. Mantené presionado para cambiarle el nombre, moverlo de carpeta o borrarlo.' },
      { icono: 'reorder-three-outline', texto: 'Para ordenar, agarrá el ícono ≡ de un documento y arrastralo: soltalo en otra carpeta, entre otros documentos o arriba, en "A la vista".' },
      { icono: 'folder-open-outline', texto: 'Los documentos se ordenan en carpetas (Documentos, Salud, Escuela). Tocá el título de una carpeta para cerrarla o abrirla; mantenelo presionado para cambiarle el nombre. Con Nueva carpeta creás las que quieras. Las carpetas también aparecen en tu Drive.' },
      { icono: 'color-palette-outline', texto: 'Verde: vigente. Naranja: vence en 30 días o menos. Rojo: vencido.' },
    ],
  },
  calendario: {
    titulo: 'Ayuda: Calendario',
    nombre: 'Calendario',
    consejos: [
      { icono: 'people-outline', texto: 'Arriba dice "Estás viendo a:" y el nombre de tu hijo. Tocalo para cambiar de hijo: se muestran los turnos del que elijas.' },
      { icono: 'add-circle-outline', texto: 'Tocá un día sin turnos para agendar uno nuevo. Para agendar otro turno en un día que ya tiene, mantené presionado ese día o usá el botón +. Si no elegís hora, es de todo el día.' },
      { icono: 'calendar-outline', texto: 'Tocá un día con turnos para ver solo los de ese día. Tocalo de nuevo para ver todos.' },
      { icono: 'hand-left-outline', texto: 'Mantené presionado un turno para editarlo o borrarlo.' },
      { icono: 'mail-outline', texto: 'Los turnos también se guardan en tu Google Calendar.' },
      { icono: 'trash-outline', texto: 'Arriba ves los turnos de hoy y los próximos. Los anteriores quedan guardados: tocá Ver turnos pasados para consultarlos o Borrar turnos viejos para limpiarlos.' },
    ],
  },
  hijos: {
    titulo: 'Ayuda: Hijos',
    nombre: 'Hijos',
    consejos: [
      { icono: 'people-outline', texto: 'Tocá Registrar hijo para crear su perfil. Podés agregar a todos los que quieras.' },
      { icono: 'search-outline', texto: 'Con la lupa buscás a tu hijo por las primeras letras de su nombre (por ejemplo "Luc"). Tocá la X para ver a todos de nuevo.' },
      { icono: 'hand-left-outline', texto: 'Mantené presionado un hijo para cambiarle el nombre o borrarlo.' },
      { icono: 'checkmark-circle-outline', texto: 'El hijo que tocás queda elegido: sus documentos y turnos aparecen en Docs y Calendario.' },
    ],
  },
  ajustes: {
    titulo: 'Ayuda: Ajustes',
    nombre: 'Ajustes',
    consejos: [
      { icono: 'logo-google', texto: 'Conectá tu cuenta de Google: es necesaria para subir documentos, agendar turnos y recibir avisos por email.' },
      { icono: 'color-palette-outline', texto: 'Elegí los colores de la app en Apariencia.' },
      { icono: 'lock-closed-outline', texto: 'Desde acá podés cambiar tu contraseña o cerrar sesión.' },
    ],
  },
};

// Rutas de las pestañas -> pantalla de la guía.
export const PANTALLA_POR_RUTA: Record<string, PantallaAyuda> = {
  '/': 'docs',
  '/index': 'docs',
  '/calendario': 'calendario',
  '/hijos': 'hijos',
  '/ajustes': 'ajustes',
};
